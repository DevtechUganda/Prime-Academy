import React, { useState } from "react";
import "./EngineeringResourceGenerator.css";

const exampleTopics = [
  "Python Data Structures",
  "ReactJS Hooks",
  "Machine Learning Overview",
  "Microservices Architecture",
  "Cloud Deployment with Docker",
  "Algorithm Analysis"
];

const exampleResource = {
  title: "Python Data Structures",
  summary: "Learn about Python's core data structures: Lists, Tuples, Sets, and Dictionaries. Understand their properties, use cases, and common operations.",
  sections: [
    {
      heading: "Introduction",
      content: "Python provides several built-in data structures, each with unique features and use cases. Knowing how and when to use each is essential for efficient coding."
    },
    {
      heading: "Lists",
      content: "A list is a mutable, ordered collection of elements. Lists support operations like append, remove, slicing, and more.\n\nExample:\n```python\nmy_list = [1, 2, 3]\nmy_list.append(4)\nprint(my_list)  # [1, 2, 3, 4]\n```"
    },
    {
      heading: "Tuples",
      content: "A tuple is an immutable, ordered collection. Useful for fixed collections of items.\n\nExample:\n```python\nmy_tuple = (1, 2, 3)\nprint(my_tuple[1])  # 2\n```"
    },
    {
      heading: "Sets",
      content: "A set is an unordered collection of unique elements. Great for membership testing and removing duplicates.\n\nExample:\n```python\nmy_set = {1, 2, 2, 3}\nprint(my_set)  # {1, 2, 3}\n```"
    },
    {
      heading: "Dictionaries",
      content: "A dictionary stores key-value pairs. Keys must be unique and immutable.\n\nExample:\n```python\nmy_dict = {'a': 1, 'b': 2}\nprint(my_dict['a'])  # 1\n```"
    },
    {
      heading: "Conclusion",
      content: "Mastering data structures allows engineers to write more efficient and readable code. Practice with real problems to solidify your understanding."
    }
  ],
  quiz: [
    {
      question: "Which Python data structure is immutable?",
      options: ["List", "Tuple", "Set", "Dictionary"],
      answer: "Tuple"
    },
    {
      question: "What is the output of print({1, 2, 2, 3})?",
      options: ["{1, 2, 2, 3}", "{1, 2, 3}", "[1, 2, 3]", "(1, 2, 3)"],
      answer: "{1, 2, 3}"
    }
  ]
};

export default function EngineeringResourceGenerator() {
  const [topic, setTopic] = useState("");
  const [resource, setResource] = useState(null);

  function handleGenerate(e) {
    e.preventDefault();
    // In a real implementation, this would call an AI/backend resource generator.
    // Here, we simulate with a fixed example.
    setResource(exampleResource);
  }

  return (
    <div className="resource-generator">
      <h2>Engineering Resource Generator</h2>
      <p>
        Type a topic or select one below to auto-generate a concise, tutorial-style resource just like <b>TutorialsPoint/GeeksforGeeks</b>.
      </p>
      <form className="resource-form" onSubmit={handleGenerate}>
        <input
          type="text"
          placeholder="Enter engineering topic (e.g., REST APIs)"
          value={topic}
          onChange={e => setTopic(e.target.value)}
          className="resource-input"
        />
        <button type="submit" className="resource-btn">Generate Resource</button>
      </form>
      <div className="example-topics">
        Example topics:
        {exampleTopics.map(t => (
          <span
            key={t}
            className="example-topic"
            onClick={() => { setTopic(t); setResource(null); }}
          >{t}</span>
        ))}
      </div>
      {resource && (
        <div className="resource-content">
          <h3>{resource.title}</h3>
          <p className="resource-summary">{resource.summary}</p>
          <div className="resource-sections">
            {resource.sections.map((sec, idx) => (
              <div key={idx} className="resource-section">
                <h4>{sec.heading}</h4>
                <pre className="resource-code">
                  {sec.content}
                </pre>
              </div>
            ))}
          </div>
          <div className="resource-quiz">
            <h4>Quick Quiz</h4>
            <ol>
              {resource.quiz.map((q, i) => (
                <li key={i}>
                  <b>{q.question}</b>
                  <ul>
                    {q.options.map((opt, j) => (
                      <li key={j} style={{color: opt === q.answer ? "#4caf50" : undefined}}>{opt}</li>
                    ))}
                  </ul>
                </li>
              ))}
            </ol>
          </div>
        </div>
      )}
    </div>
  );
}