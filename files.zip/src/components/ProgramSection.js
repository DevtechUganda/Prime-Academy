import React from "react";
import MedicalModule from "./MedicalModule";
import "./ProgramSection.css";

function ProgramSection({ name, description }) {
  return (
    <div className="program-section">
      <h3>{name}</h3>
      <p>{description}</p>
      {name === "Medical" && <MedicalModule />}
    </div>
  );
}

export default ProgramSection;