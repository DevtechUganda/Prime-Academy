# Prime Academy – Full-Stack Boilerplate & API Integration

This repository contains a modular, scalable full-stack boilerplate for the Prime Academy platform, featuring:

- React + Tailwind frontend
- Express backend
- MongoDB database
- Modular feature structure
- Rich API integrations (AI, books, video, chatbots, jobs, payments, and more)
- Ready for modern education, job placement, and student support

---

## 📂 Project Structure

```
/prime-academy
├── client/                  # React frontend
│   ├── src/
│   │   ├── components/
│   │   ├── pages/
│   │   ├── api/
│   │   ├── App.jsx
│   │   └── main.jsx
│   └── tailwind.config.js
├── server/                  # Express backend
│   ├── controllers/
│   ├── routes/
│   ├── models/
│   ├── utils/
│   └── server.js
└── README.md
```

---

## 🚀 Key Features

- **Authentication & Role Management** (Admin, Faculty, Student, etc.)
- **Mega Menu & Smart Navigation, Universal Search**
- **Automated Academic Resources:** AI notes, quizzes, video & book fetching, PDF viewer
- **AI Chatbot & WhatsApp/Voice Integration**
- **Internship & Job Board** (global & local feeds, AI resume builder)
- **LMS with Group Study, Flashcards, Coding Sandbox, Calculators**
- **Faculty Dashboards, Research Tools, Community & Support**
- **Admin Analytics, Payments, Bulk Notifications**
- **Mobile PWA & App-Ready**
- **Premium & Monetization Tools**
- **All major APIs integrated and modular**

---

## 🛠️ API Integrations

- **OpenAI GPT API:** AI summaries, flashcards, quizzes, chatbots
- **Google Books/Open Library:** Book search and previews
- **YouTube Data API:** Video learning content
- **Pinecone/LangChain:** Custom knowledge Q&A
- **Judge0:** Coding sandbox (in-browser code execution)
- **Twilio/360dialog:** WhatsApp support, SMS notifications
- **BrighterMonday/Fuzu/LinkedIn/Indeed:** Dynamic jobs & internships
- **Rezi.ai/Novoresume:** Resume generator
- **Stripe/PayPal/Mobile Money:** Payments
- **ElasticSearch/MongoDB Atlas Search:** Universal search
- **Turnitin or PlagiarismCheck:** Assignment originality

---

## 📦 Sample Implementation

### server/server.js
```javascript
const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
require('dotenv').config();

const app = express();
app.use(cors());
app.use(express.json());

const jobRoutes = require('./routes/jobs');
const aiRoutes = require('./routes/ai');
const resourceRoutes = require('./routes/resources');
const supportRoutes = require('./routes/support');

app.use('/api/jobs', jobRoutes);
app.use('/api/ai', aiRoutes);
app.use('/api/resources', resourceRoutes);
app.use('/api/support', supportRoutes);

mongoose.connect(process.env.MONGO_URI, { useNewUrlParser: true, useUnifiedTopology: true })
    .then(() => app.listen(5000, () => console.log('Server running on port 5000')))
    .catch(err => console.log(err));
```

### client/src/App.jsx
```javascript
import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Home from './pages/Home';
import Jobs from './pages/Jobs';
import Chatbot from './pages/Chatbot';
import Resources from './pages/Resources';
import Support from './pages/Support';

const App = () => (
  <Router>
    <Routes>
      <Route path='/' element={<Home />} />
      <Route path='/jobs' element={<Jobs />} />
      <Route path='/chatbot' element={<Chatbot />} />
      <Route path='/resources' element={<Resources />} />
      <Route path='/support' element={<Support />} />
    </Routes>
  </Router>
);

export default App;
```

### client/src/pages/Support.jsx
```javascript
import React from 'react';

const Support = () => (
  <div className="p-4 text-center">
    <h1 className="text-2xl font-bold mb-4">Support Channels</h1>
    <p>Reach us anytime on the platforms below:</p>
    <div className="flex justify-center gap-6 mt-6">
      <a href="https://wa.me/256752043385" target="_blank" rel="noopener noreferrer">
        <img src="/icons/whatsapp.svg" alt="WhatsApp" className="w-10" />
      </a>
      <a href="https://facebook.com/PrimeAcademyOfficial" target="_blank" rel="noopener noreferrer">
        <img src="/icons/facebook.svg" alt="Facebook" className="w-10" />
      </a>
      <a href="mailto:support@primeacademy.com">
        <img src="/icons/email.svg" alt="Email" className="w-10" />
      </a>
      <a href="https://t.me/primeacademy" target="_blank" rel="noopener noreferrer">
        <img src="/icons/telegram.svg" alt="Telegram" className="w-10" />
      </a>
    </div>
  </div>
);

export default Support;
```

---

## ⚡ Environment Variables

Place in your `.env` (never commit this file!):

```
VITE_OPENAI_API_KEY=sk-...
MONGO_URI=mongodb+srv://...
STRIPE_SECRET=...
YOUTUBE_API_KEY=...
GOOGLE_BOOKS_API_KEY=...
JUDGE0_KEY=...
REZI_API_KEY=...
TWILIO_AUTH_TOKEN=...
```

---

## 📖 Extending & Customizing

- Each feature is modular; add to `/routes/`, `/controllers/`, `/models/` (backend) and `/components/`, `/pages/`, `/api/` (frontend).
- Use the provided API integration samples as templates for new features.
- For details on advanced features, see:
  - `PRIME_ACADEMY_API_INTEGRATION_GUIDE.md`
  - `PRIME_ACADEMY_BOILERPLATE.md`
  - `FEATURES_OVERVIEW.md`
  - `FEATURES_EXTENDED.md`
  - `FEATURES_NAV_UX_TECH.md`
  - `AUTH_MONETIZATION_DESIGN.md`
  - `SYSTEM_INTEGRATION_PLAN.md`

---

## 🏁 Next Steps

- Clone the repo, configure your `.env`, and start building!
- Expand modules per your faculty, admin, or support needs.
- For questions or support, open an issue or use the Support channels.

---